import React from 'react';
import './App.css';
class App extends React.Component
{
  
  render()
  {
    
   
    return (
      <div>
        <div id="Khana Sub k Liye">
  
          <nav class="navbar navbar-expand-lg navbar fixed-top  navbar-light bg-light">
          <a class="navbar-brand" href="#Welcome to Saylani">
              <img src="assets/images/logo.png" width="50" height="50" class="d-inline-block" alt="" /> Khana Sub k Liye     </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
          </button>
            <div class="collapse navbar-collapse" id="navbarText">
              <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                    <a class="nav-link" href="#Saylani">Welcome to Saylani</a>
                  </li>
                <li class="nav-item">
                  <a class="nav-link" href="#KhanaGhar">Khana Ghar or SMIT</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#Projects">Saylani Projrct</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#Reserve">Khana Time</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#OurLocation">Our Location</a>
                </li>
              
              </ul>
          </div>
        </nav>
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block w-100 img-fluid img-slider" src="assets/images/slider1.jpg" alt="First slide" />
                <div class="carousel-caption">
                  <h2>Welcome Saylani Welfare Trust</h2>
                <p>...</p>
              </div>
              </div>
              <div class="carousel-item">
                  <img class="d-block w-100 img-fluid img-slider" src="assets/images/slider2.jpg" alt="Second slide" />
                  <div class="carousel-caption">
                  <h2>Pure Hygiene Foods</h2>
                <p>...</p>
              </div>
              </div>
              <div class="carousel-item">
                  <img class="d-block w-100 img-fluid img-slider" src="assets/images/slider3.jpg" alt="Third slide" />
                  <div class="carousel-caption">
                  <h2>Donate for Greedy People</h2>
                <p>...</p>
              </div>
              </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
          </a>
        </div>
        </div>
        <div class="container">
        <div class="row" id="KhanaGhar">
            <div class="col navMenu">
                <h2 class="text-center" >Khana Ghar or SMIT</h2>
            </div>
          </div>
          <div class="row bg-light" >
            <div class="col-md-6">
              <h3>Poor People</h3>
              <p>Those economies have just 10 percent of the world's population. About 132 million of the global poor live in areas with high flood risk</p>
              <h5>A Unique Name</h5>
              <p>Saylani Welfare International Trust is a non-government organization focusing primarily on feeding the poor and homeless. It was established in May 1999 and is headquartered at Bahdurabad, Karachi, Pakistan. It was founded and headed by spiritual and religious scholar Maulana Bashir Farooq Qadri.</p>
            </div>
            <div class="col-md-6" data-aos="fade-up">
              <img class="img-fluid" src="assets/images/location.jpg" />
            </div>
          </div>
          <div class="row bg-light"><br /></div>
          <div class="row bg-light">
            <div class="col-md-6 order-md-1 order-2" data-aos="fade-up">
              <img class="img-fluid " src="assets/images/imran.jpg" />
            </div>
            <div class="col-md-6 order-md-12 order-1">
              <h3>Hygiene Foods for Greedy People</h3>
              <p>We endeavor to provide the best quality services in areas including food, education, medical and social welfare free of cost to people living in the dark.</p>
              <h5>Halal Food</h5>
              <p>Saylani PM Lanagar Khana ... Impomented the Malaysian & Saudi Standard for Halal Food Management System with ... Sandard for Halal for Food Managoment System.</p>
            </div>
          </div>
          
        
        <div class="row" id="Projects">
          <div class="col navMenu">
                <h2 class="text-center" >Projects</h2>
          </div>
        </div>
        <div class="row bg-light">
          <div class="col-md-4" data-aos="slide-up">
            <div class="card view zoom">
                <img class="card-img-top img-fluid " src="assets/images/education.jpg" />
                <div class="card-body">
                  <h5 class="card-title">Saylani ParhaLikha Pakistan</h5>
                  <ul class="list-group list-group-flush">
                    <li class="list-group-item">Saylani Free Primary Education</li>
                    <li class="list-group-item">Saylani Free Secondary Education</li>
                  <li class="list-group-item">Saylani Free Study Expences</li>
                  <li class="list-group-item">Saylani Free Scholarship</li>
                  <li class="list-group-item">Saylani Islamic Education</li>
                </ul>
                </div>
            </div>
          </div>
          <div class="col-md-4" data-aos="slide-up">
            <div class="card">
                <img class="card-img-top img-fluid " src="assets/images/langar.jpg" />
                <div class="card-body">
                  <h5 class="card-title">Saylani Muft Rashan</h5>
                  <ul class="list-group list-group-flush">
                    <li class="list-group-item">Free Food Disribution</li>
                    <li class="list-group-item">PM & Saylani Langar Khana</li>
                  <li class="list-group-item">Saylani Free RO Water Plant</li>
                  <li class="list-group-item">Saylani WaterTank Distribution</li>
                  <li class="list-group-item">Saylani Free Health Service for Poor People</li>
                </ul>
                </div>
            </div>
          </div>
          <div class="col-md-4" data-aos="slide-up">
            <div class="card">
                <img class="card-img-top img-fluid" src="assets/images/smit.jpg" />
                <div class="card-body">
                  <h5 class="card-title">SMIT Skills Programs</h5>
                  <ul class="list-group list-group-flush">
                    <li class="list-group-item">Saylani Free Courses</li>
                    <li class="list-group-item">Sayalni Skills for Youth</li>
                  <li class="list-group-item">Saylani skills for Needy Womens</li>
                  <li class="list-group-item">Saylani Laptop scheme</li>
                  <li class="list-group-item">Saylani Internship Programs</li>
                </ul>
                </div>
            </div>
          </div>
        </div>
        <div class="row" id="Reserve">
          <div class="col navMenu">
                <h2 class="text-center">Saylani Muft Khana</h2>
          </div>
        </div>
        <div class="row">
          <div class=" col-lg-12 reserve-container" data-aos="fade-up">
            <img class="img-fluid image-reserve" src="assets/images/reserve.jpg"/>
            <div class="reserve-text col-lg-12 ">
              <h1 class="text-center">Timing</h1>
              <div class="row">
                <div class="col-6">
                    <h2 class="text-center">Breakfast</h2>
                    <h5 class="text-center">08:00 - 12:00</h5>
                </div>
                <div class="col-6">
                    <h2 class="text-center">Dinner</h2>
                    <h5 class="text-center">19:00 - 12:00</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
        <br />
        <div class="row bg-light">
          <div class="col">
            <form>
              <div class="form-row">
                  <div class="form-group col-6">
                    <h3>Register Free Food</h3>
                    <label for="inputDate"> Date</label>
                    <input type="date" class="form-control" id="inputDate" placeholder="Data gg/mm/aaaa" />
                  </div>
                  <div class="form-group col-6">
                    <h3>Details</h3>
                    <label for="inputName"> Name</label>
                    <input type="text" class="form-control" id="inputName" placeholder="Name" />
                  </div>
                  <div class="form-group col-6">
                    <label for="inputTime"> Timing to Eat Food</label>
                    <input type="time" class="form-control" id="inputTime" placeholder="Timetables" />
                  </div>
                  <div class="form-group col-6">
                    <label for="inputEmail"> CNIC</label>
                    <input type="email" class="form-control" id="inputNumber" placeholder="CNIC Number" />
                  </div>
                  <div class="form-group col-6">
                    <label for="inputNumber"> Number of Food Packet</label>
                    <input type="number" class="form-control" id="inputNumber" placeholder="Person to Eat Food" />
                  </div>
                  <div class="form-group col-6">
                    <label for="inputCel"> Phone</label>
                    <input type="tel" class="form-control" id="inputCel" placeholder="Phone" />
                  </div>
                  <div class="form-group col-12">
                    <label for="inputComment"> Any Request To Saylani</label>
                  <textarea class="form-control" rows="4" id="inputComment" placeholder="Please Request"></textarea>
                </div>
              </div>
              <div class="row">
                  <div class="col-md-4 col-md-offset-4">
                    <button type="submit" class="btn btn-secondary btn-block">Request free Food</button>
                  </div>
                </div>
            </form>
          </div>
        </div>
        <div class="row" id="OurLocation">
          <div class="col navMenu">
            <h2 class="text-center">Our Location</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3">
            <h3>Address:</h3>
            <p>Bahdurabad Chaar Minar</p>
            <h3>Email:</h3>
            <p>mail@Saylani.com</p>
          </div>
        </div>
        <div class="row footer bg-light">
          <div class="col">
            <p class="text-center">Follow us: 
              <a class="social-icon" href="#"><i class="fab fa-facebook"></i></a> 
              <a class="social-icon" href="#"><i class="fab fa-instagram"></i></a></p>
          </div>
          <div class="col">
            <p class="text-center">Copyright &copy; 2021</p>
          </div>
          <div class="col">
            <p class="text-center">Supported by: <a href="#">Saylani SMIT TEAM</a></p>
          </div>
        </div>
    </div>
  </div>
) } }
 export default App;